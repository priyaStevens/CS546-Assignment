const dbConnection = require('../config/mongoConnection');
const data = require('../data/');
const band = data.bands;
const album = data.albums;
const collection = require('../config/mongoCollections');
const bandcollection = collection.band; 

const main = async () => {
	const db = await dbConnection();
    await db.dropDatabase();
    console.log("start");
    
    const firstBand = await band.addBand(
        "Pink Floyd",
        ["Roger Waters","David Gilmour", "Richard Wright", "Nick Mason"],
        1965,
         ["Psychedelic rock", "Classic Rock", "Rock"],
        "Columbia Records",
            );
    console.log ("band added")
 
     const bandCollectionVal = await bandcollection();
     const bandVal = await bandCollectionVal.findOne({ bandName: "Pink Floyd" });
     console.log(bandVal._id);
     let author = bandVal._id

    const firstAlbum = await album.addAlbum(
        "The Wall",
        author,
        ["In the Flesh?", "The Thin Ice", "Another Brick in the Wall Part 1"]
    )
	await db.serverConfig.close();
};

main();

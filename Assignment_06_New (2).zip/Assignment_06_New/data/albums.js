const collection = require('../config/mongoCollections');
const albumCollection = collection.album;
const bandCollection = collection.band;
const bands = require("./bands");
const ObjectId = require('mongodb').ObjectID;
const mongoose = require('mongoose');


function isValidString(datavalue,data){
    if(datavalue != " " && datavalue!=undefined && typeof datavalue ==="string"){
    return datavalue.trim();
    }
    throw `${datavalue} is not a valid input, you must provide valid input for ${data}`;
    }
    
async function addAlbum(title,author,songs){
   if(!title || !author || !songs) throw `input is not valid`;

    if((!Array.isArray(songs)) || !(songs.length>=0)) throw "please provide array of songs";
    for(let i=0; i<songs.length; i++){
        isValidString(songs[i],"song")
    }

    isValidString(title,"title");
    if(!(/[a-zA-Z]/.test(title))) throw 'title is not valid.'

const albumVal = await albumCollection();
const bandVal = await bandCollection();

if(typeof author !="object"){
    author  = ObjectId.createFromHexString(author);
}

const ifAlbumExists = await bandVal.findOne({_id : author});
if(ifAlbumExists === null){
    throw `Author for id ${id} does not exists`;
}

    let newAlbum = {
        title:title,
        author:author.toString().trim(),
        songs:songs
    }

    const insertInfo = await albumVal.insertOne(newAlbum);
    if (insertInfo.insertedCount === 0) throw 'Could not add album';

    const newId = insertInfo.insertedId;
// for making album enteries to band collection.
    const addAlbumtoBand = await this.addAlbumToBand(author, newId);
    
    const album = await this.getAlbumById(newId);

    return album;
}

async function addAlbumToBand(bandId, album) {
    const bandVal = await bandCollection();
    
    if(typeof bandId !="object"){
        bandId  = ObjectId.createFromHexString(bandId);
        console.log(bandId);
    }

    const updatedInfo = await bandVal.updateOne({ _id: bandId }, { $addToSet: { albums: album} })
    if(updatedInfo.modifiedCount === 0){
        throw `could not update author ${bandId}`;
    }
    return true;
  }

async function getAlbumById(id){
    if (!id) throw 'You must provide an id to search for';

        const albumVal = await albumCollection();
        
        if(typeof id !="object"){
            id  = ObjectId.createFromHexString(id);
        }

		const albumDetail = await albumVal.findOne({ _id: id });
		if (albumDetail === null) throw 'No album with that id';

		return albumDetail;
}

async function getAllAlbums(){
    const albumVal = await albumCollection();
    
    const bandVal = await bandCollection();
    const albumList = await albumVal.find({}).toArray(); 
    return albumList;
}

async function updateAlbum(id, updatedAlbum){
    
    const updatedAlbumData = {};
    
    if(updatedAlbum.title){
        updatedAlbumData.title = updatedAlbum.title;
    }
    if(updatedAlbum.author){
        updatedAlbumData.author = updatedAlbum.author;
    }
    if(updatedAlbum.songs){
        updatedAlbumData.songs = updatedAlbum.songs;
    }

    if(typeof id !="object"){
        id  = ObjectId.createFromHexString(id);
    } 

    let author = null;
    console.log(updatedAlbumData);

    if(updatedAlbumData.title === undefined && updatedAlbum.songs === undefined) throw 'there is not data to update.'

     const albumCollVal = await albumCollection();

      const updatedAlbumVal = await albumCollVal.updateOne({_id: id}, {$set: updatedAlbumData});

      if(updatedAlbumVal.modifiedCount === 0)
      {
        throw `could not update album for id ${id}`;
    }
        
    return await this.getAlbumById(id);

}

async function removeAlbum(id){
    if (!id) throw 'You must provide an id to search for';

        const albumCollVal = await albumCollection();

        if(typeof id !="object"){
            id  = ObjectId.createFromHexString(id);
        }
        const beforeRemovedata = await this.getAlbumById(id);

        const removedInfo = await albumCollVal.removeOne({ _id: id});
        console.log(removedInfo);
		if (removedInfo.deletedCount === 0) {
			throw `Could not delete album with id of ${id}`;
        }

    const result = {};
    result["deleted"] = "true";
    result["data"] = [beforeRemovedata]
     return result;
}

async function removeAlbumfromBand(id, albumId){
    if (!id) throw 'You must provide an id to search for';

    const albumCollVal = await albumCollection();
    const bandCollVal = await bandCollection();
    
    let authorId = id;

    if(typeof authorId !="object"){
        authorId  = ObjectId.createFromHexString(authorId);
    }
    if(typeof albumId !="object"){
        albumId  = ObjectId.createFromHexString(albumId);
    }  
          let updatedbandData = await bandCollVal.updateOne({ _id: authorId }, { $pull: { albums: albumId } })
            if(updatedbandData.modifiedCount === 0){

}

}

module.exports = {
    addAlbum,
    getAlbumById,
    getAllAlbums,
    updateAlbum,
    removeAlbum,
    addAlbumToBand,
    removeAlbumfromBand
}
const users = require("./users.js");
const bcrypt = require("bcrypt");
const saltRounds = 16;

let userData = new Object();
const getIndex =(key, value)=>{
    for(let i in users){
        if((users[i])[key] === value)
        return i;
    }
};

const getPassword= username =>{
const i = getIndex("Username",username);
if(i)
return users[i].HashedPassword;
}

const matchPassword = (requestedPassword, userPassword)=>{
    return bcrypt.compareSync(requestedPassword, userPassword);
}

const setSession=(userName, sessionUser)=>{
    const i = getIndex("Username",User);
    if(i)
    users[i].Username = sessionUser;
}

const getUserfromSession = (sessionUser) =>{
    const i = getIndex("Username",sessionUser);
     if(i != undefined)
     {userData["Username"] = users[i].Username;
     userData["FirstName"] = users[i].FirstName;
     userData["LastName"] = users[i].LastName;
     userData["Profession"] = users[i].Profession;
     userData["Bio"] = users[i].Bio;
}
    return userData;
}

const validSession = (sessionId)=>{
    const i = getIndex("_id",sessionId);
    if (i) 
    return true;
    else
    return false;
}

module.exports={
    getIndex,
    getPassword,
    matchPassword,
    setSession,
    getUserfromSession,
    validSession

}
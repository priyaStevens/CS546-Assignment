const words ={
    programming: "The action or process of writing computer programs.",
    charisma: "A personal magic of leadership arousing special popular loyalty or enthusiasm for a public figure (such as a political leader)",
    sleuth: "To act as a detective : search for information",
    foray: "A sudden or irregular invasion or attack for war or spoils : raid",
    adjudicate: "to make an official decision about who is right in (a disput: to settle judicially"
}

function chcekInput(words){
  
if(typeof(words) == string){
    return words;
}
else{
    throw("not a string");
}
}

function lookupDefinition(anyThing ){
    try{
    chcekInput(anyThing)}
    catch(error){console.error();
    }
}


if (words[key] != undefined){
    return words[value];
}else{
    throw "there is an error";
}

function getWord(value){
    if (chcekInput(value)){
    return words.keys.find(x=> x == value);}
}

module.exports={
    lookupDefinition,
    getWord
};
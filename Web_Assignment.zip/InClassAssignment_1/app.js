
var msg = require('./dictionary.js');
console.log("priya");
const words ={
    programming: "The action or process of writing computer programs.",
    charisma: "A personal magic of leadership arousing special popular loyalty or enthusiasm for a public figure (such as a political leader)",
    sleuth: "To act as a detective : search for information",
    foray: "A sudden or irregular invasion or attack for war or spoils : raid",
    adjudicate: "to make an official decision about who is right in (a disput: to settle judicially"}

try{
    console.log(msg.lookupDefinition(words));
}
catch(error){
    console.error;
}
try{
    console.log(msg.getWord(words));
}
catch(error){
    console.error;
}

const geometry = require("./geometry");
const utility = require("./utilities");


const first = {a: 2, b: 3};
const second = {a: 2, b: 4};
const third = {a: 2, b: 3};
const fourth = {b: 2, a: 3, c:5};
const fifth = "ab";

// to count deep equality of object
// try{
// const value = utility.deepEquality(first,second);
// console.log(value);
// }
// catch(e){
//     console.log(e);
// }


// to count unique lement 
// try{
//     let countUniqueElement = utility.uniqueElements(["a", "a", "b", "a", "b", "c","d","d"]);
//     console.log(countUniqueElement);
// }
// catch(e){
//     console.log(e);
// }


//---- to count no unique element in the string
// try{
//     const test = "Hello, the pie is in the oven";
//     let countUniqueElement = utility.countOfEachCharacterInString(test);
//     console.log(countUniqueElement);
// }
// catch(e){
//     console.log(e);
// }


//---- to calculate volume of rectangular prism

  try{
     let volumeOfRectangularPrism = geometry.volumeOfRectangularPrism(-15,7,-8);
     console.log(volumeOfRectangularPrism);
 }
 catch(e){console.log(e)};


//---- to calculate surface area of rectangular prism

// try{
//   let surfaceAreaOfRectangularPrism =  geometry.surfaceAreaOfRectangularPrism(1,7,8);
//   console.log(surfaceAreaOfRectangularPrism);
// }
// catch(e){console.log(e);
// }


// //---- to calculate volume of sphere
// try{
//    let volumeOfSphere =  geometry.volumeOfSphere(9);
//    console.log(volumeOfSphere);
// }
// catch(e){console.log(e);
// }


// // //---- to calculate surface area of sphere
// try{
//    let surfaceAreaOfSphere= geometry.surfaceAreaOfSphere(6);
//    console.log(surfaceAreaOfSphere);
// }
// catch(e){console.log(e);
// }
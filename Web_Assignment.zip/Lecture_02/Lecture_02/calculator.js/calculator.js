

function addTwoNumbers(num1, num2){
    return num1+num2;
}

 function substarctTwoNumbers(num1, num2){
     return num1-num2;
 }
 
  function multiplyTwoNumbers(num1, num2){
     return num1*num2;
 }

 function divideTwoNumbers(num1, num2){
     return num1*num2;
 }

module.exports = {
    addTwoNumbers
  
};
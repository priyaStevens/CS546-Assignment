const calculator = require('./calculator.js');
 //const prompt = require('prompt');

console.log('Priya');

//  try{
//  console.log(calculator.addTwoNumbers(1,'gupta'));

//  }
//  catch(error){
//      console.error()};

 
    
//     try{
//         console.log(calculator.multiplyTwoNumbers(undefined,1));}
//     catch(error){
//         console.error();
        
//     }

//     console.log("Hello there");

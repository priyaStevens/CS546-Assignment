const mongoCollections = require("../mongoCollections");
const animals = mongoCollections.animals;
const ObjectId = require('mongodb').ObjectID;


function  isStringId(idValue){
    if(typeof idValue != "string"){
        throw `id ${idValue} is not valid.`;
    }
   if(typeof idValue != "string" || idValue.length!=24){
       throw `id ${idValue} is not valid.`;
   }
   for(let i=0; i<=idValue.length; i++){
  if(/^[!@#\$%\^\&*\)\(+=._-]+$/g.test(idValue.charAt(i))){
    throw `id ${idValue} is not valid.`;
  }
}
   return idValue;
}
      

function isValidValue(datavalue,data){
if(datavalue != " " && datavalue!=undefined && typeof datavalue ==="string" && /[a-zA-Z]/.test(datavalue)){
return datavalue;
}
throw `${datavalue} is not a valid input, you must provide valid input for ${data}`;
}



module.exports = {

    async create(name, animalType){

        isValidValue(name.trim(),"name");
        isValidValue(animalType.trim(),"animalType");

        const animalCollection = await animals();

        let newAnimal ={
            name: name.trim(),
            animalType: animalType.trim()
        }

        const insertInfo = await animalCollection.insertOne(newAnimal);
        if (insertInfo.insertedCount === 0) throw 'Could not create animal';
        
        const newId = insertInfo.insertedId;

        const animal = await this.get(newId);
		return animal;
    },


    async getAll(){
        const animalCollection = await animals();

        const animalList = await animalCollection.find({}).toArray();
        
        if(animalList.length <= 0){
        throw "no animal data is available in animal collection."
        }
        return animalList;

    },

    async get(id){
        if (!id) throw 'You must provide an id to search for';

        const animalCollection = await animals();

       if(typeof id != "object"){
           if (isStringId(id));
           id = ObjectId.createFromHexString(id);
       }
        
        const getanimal = await animalCollection.findOne({ _id: id });

        if (getanimal === null) {
        throw `No animal with that id ${id}`;}

		return getanimal;
    },


    async remove(id){
        if (!id) throw 'You must provide an id to search for';

        const animalCollection = await animals();

        if(typeof id != "object"){
            if (isStringId(id));
            id = ObjectId.createFromHexString(id);
        }

        const getId = await this.get(id);

        const deletionInfo = await animalCollection.deleteOne({ _id: id });

		if (deletionInfo.deletedCount === 0) {
			throw `Could not delete animal with id of ${id}`;
		}
		return getId;
    },


    async rename(id, newName){
        if (!id) throw 'You must provide an id to search for';
       if(isValidValue(newName.trim(),"newname"));

        const animalCollection = await animals();

        let updatedAnimal ={
            name: newName.trim()
        };
        

        if(typeof id != "object"){
            if (isStringId(id));
            id = ObjectId.createFromHexString(id);
        }

        const updatedInfo = await animalCollection.updateOne({ _id: id }, { $set: updatedAnimal });
        if(updatedInfo.matchedCount === 0){
            throw  `no animal exists with id of ${id}`;
        }
		if (updatedInfo.modifiedCount === 0) {
			throw 'could not update animal successfully';
        }
        
        const getupdatedInfo = await this.get(id);
        return getupdatedInfo;


    }


}
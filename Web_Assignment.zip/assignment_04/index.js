const animal = require("./data/animals");
// const connection = require("./mongoConnection");
 const mongoCollections = require("./mongoCollections");
 const animals = mongoCollections.animals;

async function main(){

   //Create an animal named Sasha with the type of Dog.
    try{
          const animalSasha = await animal.get("5e56c605ea6a8f1ec0f94");
         // Log the newly created animal
          console.log(animalSasha);
    }
    catch(e){
        console.log(e);
    }

  // //Create an animal named Sasha with the type of Dog.
  //   try{
  //         const animalSasha = await animal.create("Sasha","dog");
  //        // Log the newly created animal
  //         console.log(animalSasha);
  //   }
  //   catch(e){
  //       console.log(e);
  //   }

  //   //Create an animal named Lucy, with the type of Dog.
  //   try{
  //         const animalLucy = await animal.create("Lucy","Dog");
  //   }
  //   catch(e){
  //       console.log(e);
  //   }

  //   //Query all animals, and log them all
  //   try{
  //         const getAllAnimals = await animal.getAll();
  //         console.log(getAllAnimals);
  //   }
  //   catch(e){
  //       console.log(e);
  //   }

  //   //Create an animal named Duke, with a type of Walrus
  //   try{
  //         const animalDuke = await animal.create("Duke","Walrus");
  //   //Log the newly created Duke
  //         console.log(animalDuke);
  //   }
  //   catch(e){
  //       console.log(e);
  //   }
      
  //   //Rename Sasha to Sashita
  //     try{
  //       const animalCollection = await animals();
  //       const animalval = await animalCollection.findOne({ name: "Sasha" });
  //     if(animalval == undefined || animalval == null)
  //       {
  //           throw "no animal exists with the name Sasha.";
  //     }
  //     const renameSasha = await animal.rename(animalval._id, "Sashita");
  //     //Log the newly named Sashita
  //     console.log(renameSasha);
  //   }       
  //   catch(e){
  //       console.log(e);
  //   }

  //   //Remove Lucy
  //   try{
  //       const animalCollection = await animals();
  //       const animalLucyval = await animalCollection.findOne({ name: "Lucy" });
  //       if(animalLucyval == undefined || animalLucyval == null){
  //           throw "no animal exists with the name Lucy.";
  //       }
  //     const removeAnimal = await animal.remove(animalLucyval._id);
  //   }
  //   catch(e){
  //       console.log(e);
  //   }

  //   //Query all animals, and log them all
  //   try{
  //     const getAll = await animal.getAll();
      
  //     console.log(getAll);
  //   }
  //   catch(e){
  //     console.log(e);
  //   }
}

main().catch((error)=>{
    console.log(error);
});
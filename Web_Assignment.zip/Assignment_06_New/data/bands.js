const collection = require('../config/mongoCollections');
const bandCollection = collection.band;
const albumCollection = collection.album;
const ObjectId = require('mongodb').ObjectID;
const albums = require("./albums");


function isValidString(datavalue,data){
    if(datavalue != " " && datavalue!=undefined && typeof datavalue ==="string" && /[a-zA-Z]/.test(datavalue)){
    return datavalue.trim();
    }
    throw `${datavalue} is not a valid input, you must provide valid input for ${data}`;
    }
async function addBand(bandName, bandMembers, yearFormed, genres, recordLabel){

    if (!bandName || !bandMembers || !yearFormed || !genres || !recordLabel) throw 'Input data provided is not correct';

     if ((!Array.isArray(bandMembers)) || !(bandMembers.length>=0)) throw 'You must provide an array of bandMembers';
     for(let i=0 ; i<=bandMembers.length-1; i++){
        isValidString(bandMembers[i],"bandMember");
    }

    if((!Array.isArray(genres)) || !(genres.length>=0)) throw 'You must provide an array of genres';
    for(let i=0 ; i<=genres.length-1; i++){
        isValidString(genres[i],"genres");
    }

    isValidString(bandName,"bandName");

    isValidString(recordLabel,"recordLabel");

    if(typeof yearFormed !== "number") throw 'yearFormed should be a Number input.';
   

const bandVal = await bandCollection();

    let newBand = {
        bandName: bandName, 
        bandMembers: bandMembers,
        yearFormed:yearFormed,
        genres:genres,
        albums: [],
        recordLabel:recordLabel
    };

    const insertInfo = await bandVal.insertOne(newBand);
    if (insertInfo.insertedCount === 0) throw 'Could not add band';

    const newId = insertInfo.insertedId;

    const band = await this.getBandById(newId);
    //return band;
   return band;
}

async function getBandById(id){
    if (!id) throw 'You must provide an id to search for';

        const bandVal = await bandCollection();

        if(typeof id !="object"){
         id  = ObjectId.createFromHexString(id);
        }
        const bandDetail = await bandVal.findOne({ _id: id });

		if (bandDetail === null) throw 'No band with that id';

		return bandDetail;
}

async function updateBand(bandId, bandName, bandMembers, yearFormed, genres, recordLabel){

    if (!bandId) throw 'You must provide an id to search for';

    if (!bandId || !bandName || !bandMembers || !yearFormed || !genres || !recordLabel) throw 'You must provide valid data.';

            if ((!Array.isArray(bandMembers)) || !(bandMembers.length>=0)) throw 'You must provide an array of bandMembers';
            for(let i=0 ; i<=bandMembers.length-1; i++){
                isValidString(bandMembers[i],"bandMember");
            }

            if((!Array.isArray(genres)) || !(genres.length>=0)) throw 'You must provide an array of genres';
            for(let i=0 ; i<=genres.length-1; i++){
                isValidString(genres[i],"genre");
            }
            
            isValidString(bandName,"bandName");

            isValidString(recordLabel,"recordLabel");

            if(typeof yearFormed !="number") throw "year formed should be a number.";

            if(typeof bandId !="object"){
                bandId  = ObjectId.createFromHexString(bandId);
               }

               const bandVal = await bandCollection();

               const currentData = await bandVal.findOne({_id : bandId});
               let currentAlbumData = [];
               if(currentData.albums){
                currentAlbumData = currentData.albums
               }

                let updatedband = {
                    bandName: bandName, 
                    bandMembers: bandMembers,
                    yearFormed:yearFormed,
                    genres:genres,
                    albums: currentAlbumData,
                    recordLabel:recordLabel
                };

		const updatedInfo = await bandVal.updateOne({ _id: bandId }, { $set: updatedband });
		if (updatedInfo.modifiedCount === 0) {
			throw 'could not update band successfully';
		}

		return await this.getBandById(bandId);
}


async function removeBand(id){
    if (!id) throw 'You must provide an id to search for';
        const bandCollVal = await bandCollection();

        if(typeof id !="object"){
            id  = ObjectId.createFromHexString(id);
        }

        const beforeRemovedata = await this.getBandById(id);
        const removedInfo = await bandCollVal.removeOne({ _id: id});
		if (removedInfo.deletedCount === 0) {
			throw `Could not delete band with id of ${id}`;
        }

    const result = {};
    result["deleted"] = "true";
    result["data"] = [beforeRemovedata]
     return result;
}

async function removeAlbumforBand(id){

    const albumCollVal = await albumCollection();
    const ifAlbumExsits = await albumCollVal.findOne({author : id.toString()});

    if(ifAlbumExsits !== null){
    const albumId = ifAlbumExsits._id; 
    if(typeof albumId !="object"){
        albumId = ObjectId.createFromHexString(albumId);
    }   
    const removeAlbum =await albumCollVal.removeOne({ _id: albumId});

    if(removeAlbum.deletedCount === 0){
        throw `could not delete album for author ${id}`;
    }
}
}

  async function getAllBands() {
    const bandVal = await bandCollection();
    const bandList = await bandVal.find({}).toArray();
 
      return bandList;
 }

module.exports = {
    getAllBands,
    addBand,
    updateBand,
    getBandById,
    removeBand,
    removeAlbumforBand
}
const bandRoutes = require("./bands");
const albumRoutes = require("./albums");

const constructorMethod = app => {
  app.use("/bands", bandRoutes);
  app.use("/albums", albumRoutes);

  app.use("*", (req, res) => {
    
    res.status(400).json({ message: "not found!" })
  });
};

module.exports = constructorMethod;
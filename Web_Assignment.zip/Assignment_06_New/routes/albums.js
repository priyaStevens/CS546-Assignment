const express = require("express");
const router = express.Router();
const data = require("../data");
const albumData = data.albums;
const bandData = data.bands;
const ObjectId = require('mongodb').ObjectID;

router.get("/:id", async (req, res) => {
    try {
      const album = await albumData.getAlbumById(req.params.id);

      if(typeof album.author != "object"){
        album.author  = ObjectId.createFromHexString(album.author);
      }

      const data = await bandData.getBandById(album.author);
 
      if(!data || data == undefined)
      res.status(404).json({ error: 'there is no author in band for this album' });

      let newData = {};
      newData["_id"] = data._id;
      newData["BandName"] = data.bandName;

      album.author = newData;

      res.status(200).json(album);
    } catch (e) {
      res.status(404).json({ message: "not found!" });
    }
  });

router.get("/", async (req, res) => {
    try {
      const bandList = await bandData.getAllBands();
      const albumList = await albumData.getAllAlbums();

      let data ="";

      for(let i=0; i<=albumList.length-1;i++){
          
       data =  bandList.find(element => String(element._id) === albumList[i].author);

       if(!data || data == undefined)
       res.status(404).json({ error: 'there is no author in band for this album' });

       let newData = {};
       newData["_id"] = data._id;
       newData["BandName"] = data.bandName;

       albumList[i].author = newData;
       
      }

      res.status(200).json(albumList);

    } catch (e) {
      // Something went wrong with the server!
      res.status(404).json({ message: "not found!" });
    }
  });

  router.post("/", async(req,res)=>{
    try{
      const albumPostData = req.body;   

      const addedAlbum = await albumData.addAlbum(albumPostData.title,albumPostData.author,albumPostData.songs );

      if(typeof addedAlbum.author != "object"){
        addedAlbum.author  = ObjectId.createFromHexString(addedAlbum.author);
      }

      const data = await bandData.getBandById(addedAlbum.author);
 
      if(!data || data == undefined)
      res.status(404).json({ error: 'there is no author in band for this album' });

       let newData = {};
       newData["_id"] = data._id;
       newData["BandName"] = data.bandName;

      addedAlbum.author = newData;
      res.status(200).json({ addedAlbum });
    }
    catch(e){
      res.status(500).json({ error: e.message });
    }
    })

    router.patch('/:id', async (req, res) => {
      const requestBody = req.body;
  
      let updatedObject = {};
 
      try{
        const oldAlbum = await albumData.getAlbumById(req.params.id);
        
        if (requestBody.title && requestBody.title !== oldAlbum.title) updatedObject.title = requestBody.title;
        if(requestBody.author && requestBody.author !== oldAlbum.author) updatedObject.author = requestBody.author;
        if(requestBody.songs && requestBody.songs !== oldAlbum.songs) updatedObject.songs = requestBody.songs;

      }
      catch(e){
        res.status(404).json({ error: 'album not found' });
        return;
      }
      try{
        const updatedAlbum = await albumData.updateAlbum(req.params.id,updatedObject);

        if(typeof updatedAlbum.author != "object"){
          updatedAlbum.author  = ObjectId.createFromHexString(updatedAlbum.author);
        }
  
        const data = await bandData.getBandById(updatedAlbum.author);
   
        if(!data || data == undefined)
          res.status(404).json({ error: 'there is no author in band for this album' });
  
         let newData = {};
         newData["_id"] = data._id;
         newData["BandName"] = data.bandName;
  
         updatedAlbum.author = newData;

        res.status(200).json(updatedAlbum);
      }
      catch(e){
        res.status(500).json({ error: e });
      }
    })

    router.delete("/:id", async (req, res) => {
      try {
        await albumData.getAlbumById(req.params.id);
      } catch (e) {
        res.status(404).json({ error: "album not found" });
      }
      try {
        const result = await albumData.removeAlbum(req.params.id);

        if(typeof result.data[0].author != "object"){
          result.data[0].author  = ObjectId.createFromHexString(result.data[0].author);
        }

        const data = await bandData.getBandById(result.data[0].author);

        if(!data || data == undefined)
        res.status(404).json({ error: 'there is no author in band for this album' });
  
        let newData = {};
        newData["_id"] = data._id;
        newData["BandName"] = data.bandName;
  
        result.data[0].author = newData;

      const deletedAlbumfromband =  await albumData.removeAlbumfromBand(result.data[0].author._id, result.data[0]._id);

        res.status(200).json(result);
      } catch (e) {
        res.status(500).json({ error: e });
      }
    });


  module.exports = router;
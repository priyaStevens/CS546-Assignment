const express = require("express");
const router = express.Router();
const data = require("../data");
const bandData = data.bands;
const albumData = data.albums;

router.put("/:id", async(req,res)=>{
  const bandInfo = req.body;  
  if(!bandInfo){
    res.status(400).json({ error: "You must provide data to update a band" });
    return;
  }
if(!bandInfo.bandName)
  {
    res.status(400).json({ error: "You must provide data to update a bandName" });
    return;
  }
  if(!bandInfo.bandMembers)
  {
    res.status(400).json({ error: "You must provide data to update a bandMembers" });
    return;
  }
  if(!bandInfo.genres)
  {
    res.status(400).json({ error: "You must provide data to update a genres" });
    return;
  }
 if(!bandInfo.recordLabel)
  {
    res.status(400).json({ error: "You must provide data to update a recordLabel" });
    return;
  }
   try {
   await bandData.getBandById(req.params.id);
  
  } catch (e) {
    res.status(404).json({ error: "band not found" });
  }
  try{
    
  const updatedband = await bandData.updateBand(req.params.id,bandInfo.bandName,bandInfo.bandMembers,bandInfo.yearFormed,bandInfo.genres,bandInfo.recordLabel);

  const albumList = await albumData.getAllAlbums();

      let albumArray  = [];
      let data ="";

      if(updatedband.albums){
      albumArray = updatedband.albums;

     for(let i =0; i<=albumArray.length-1; i++){

      data =  albumList.find(element => String(element._id) === String(albumArray[i]));

      if(!data || data == undefined)
      res.status(400).json({ error: "there is no album for this band in albums" });

      let newData = {};
      newData["_id"] = data._id;
      newData["title"] = data.title;
      newData["author"] = data.author;
      newData["songs"] = data.songs;

      albumArray[i] = newData;
     }
    }

  res.status(200).json(updatedband);
  }
  catch(e){
    res.status(500).json({ error: e });
  }
  })
router.get("/:id", async (req, res) => {
  try {
    const band = await bandData.getBandById(req.params.id.toString());
    const albumList = await albumData.getAllAlbums();

      let albumArray  = [];
      let data ="";
      albumArray = band.albums;

     for(let i =0; i<=albumArray.length-1; i++){

      data =  albumList.find(element => String(element._id) === String(albumArray[i]));

      if(!data || data == undefined)
      res.status(400).json({ error: "there is no album for this band in albums" });

      let newData = {};
      newData["_id"] = data._id;
      newData["title"] = data.title;
      newData["author"] = data.author;
      newData["songs"] = data.songs;

      albumArray[i] = newData;
     }
     res.status(200).json(band);
  } 
  catch (e) {
    res.status(400).json({ error: 'not found!'});
  }
})

router.get("/", async (req, res) => {
  try {
    const bandList = await bandData.getAllBands();
    const albumList = await albumData.getAllAlbums();
  
    let data ="";

    for(let i=0; i<=bandList.length-1;i++){
      let albumArray = [];
      albumArray = bandList[i].albums;

      for(let j=0; j<albumArray.length; j++){
      
      data =  albumList.find(element => String(element._id) === String(albumArray[j]));
        if(!data || data == undefined)
        res.status(400).json({ error: "there is no album for this band in albums" });
      
       let newData = {};
       newData["_id"] = data._id;
       newData["title"] = data.title;
       newData["author"] = data.author;
       newData["songs"] = data.songs;

       albumArray[j] = newData;

      }
    }
    res.status(200).json(bandList);
  } catch (e) {
    // Something went wrong with the server!
    res.status(400).json({ error: 'not found!' });
  }
})

router.post("/", async(req,res)=>{
try{
  const bandPostData = req.body;
  const { bandName, bandMembers, yearFormed, genres, recordLabel } = bandPostData;

  const addBand = await bandData.addBand(bandName,bandMembers,yearFormed,genres,recordLabel);
  res.status(200).json(addBand);
}
catch(e){
  res.status(500).json({ error: e });
}
})

router.delete("/:id", async (req, res) => {
  try {
    await bandData.getBandById(req.params.id);
  } catch (e) {
    res.status(404).json({ error: "band not found" });
  }
  try {
    const result = await bandData.removeBand(req.params.id);

    const albumList = await albumData.getAllAlbums();

      let albumArray  = [];
      let data ="";
      albumArray = result.data[0].albums;

     for(let i =0; i<=albumArray.length-1; i++){

      data =  albumList.find(element => String(element._id) === String(albumArray[i]));

      if(!data || data == undefined)
      res.status(400).json({ error: "there is no album for this band in albums" });

      let newData = {};
      newData["_id"] = data._id;
      newData["title"] = data.title;
      newData["author"] = data.author;
      newData["songs"] = data.songs;

      result.data[0].albums[i] = newData;
     }
const deleteAlbum =  await bandData.removeAlbumforBand(req.params.id)

    res.status(200).json(result);
  } catch (e) {
    res.status(500).json({ error: e });
  }
});


module.exports = router;
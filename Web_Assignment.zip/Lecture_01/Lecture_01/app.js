let myKey = "priya"
debugger
console.log(mykey);
const questionOne = function questionOne(arr) {
    // Implement question 1 here
    if(arr.length>0){
    let sqrArr = arr.map((x)=>{
      return  x*x;
    })
     return  sqrArr.reduce((a, b) => a + b, 0)
}
}

const questionTwo = function questionTwo(num) { 
        if(num==0 || num==1){
            return num;
        }
        
            return questionTwo(num-1)+ questionTwo(num-2)
        
    };



const questionThree = function questionThree(text) {
    
    let count=0;
    let vowels = ['a','e','i','o','u'];
    for(let i=0; i<=text.length; i++){
     // console.log(text.charAt(i));
      if (vowels.find(element => element == text.charAt(i))){
          count = count+ 1;
      }
     
    }
    return count;
    
}

const questionFour = function questionFour(num) {
    // Implement question 4 here
    if(num>=0){
    if(num==0){
        return 1;
    }  
    for(let i=num;i>=1; i--){
        return i*(questionFour(i-1));
    }}
    else{
        return NaN;
    }
}

module.exports = {
    firstName: "Priya", 
    lastName: "Gupta", 
    studentId: "10457442",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};
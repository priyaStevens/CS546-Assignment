var abc = "hello word"
console.log(abc);

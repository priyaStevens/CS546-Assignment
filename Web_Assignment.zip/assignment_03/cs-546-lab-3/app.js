const bluebird = require("bluebird");
const Promise = bluebird.Promise;

const prompt = bluebird.promisifyAll(require("prompt"));
const fs = bluebird.promisifyAll(require("fs"));


const fileData = require("./fileData");
const textMetrics = require("./textMetrics");

let path = 'chapter2.result.json';
//let path = '';

async function main(pathVal){
    if(pathVal == "")
    {
        throw "path is null."
    }
    if(pathVal == undefined){
        throw "please enter valid path;"
    }

    let getPath = pathVal.substr(0, pathVal.indexOf('.'))+ '.result.json'; 
   let ReadPath = pathVal.substr(0, pathVal.indexOf('.')) + '.txt';


try{
    if (fs.existsSync(getPath)) {
        const getJsonFile = await fileData.getFileAsJSON(getPath);
        console.log(getJsonFile);
    }
    else
    {
         //const strdata = await fileData.getFileAsString(ReadPath); 
         const strdata = "woop-thst seven--who this's "
         const getTextMetrics = await textMetrics.createMetrics(strdata);
        console.log(getTextMetrics);
        const saveJsonFile = await fileData.saveJSONToFile(getPath,getTextMetrics);
    
    }    
}
catch(e){
  console.log(e);       
    }
}



main(path,(err,result)=>{
    if(err){
        throw err;
    }
});

setInterval(() => {
   console.log("hello"); 
}, 1000);

const list =['man', 'womne', 'child'];

newlist = list.map(val)
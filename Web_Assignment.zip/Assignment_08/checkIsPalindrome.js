
const getText = (str) => {
    return str.replace(/\W/g, '').toLowerCase();
};

const exportedMethods = {
    async isPalindrome(params) {
        let str = params['text-to-test'];
    
        if(!str) throw "Empty text is supplied in the body";
    
        str = getText(str);
    
        if(!str) throw "Invalid text supplied in the body";
        
        return str === str.split('').reverse().join('');
    }
};

module.exports = exportedMethods;
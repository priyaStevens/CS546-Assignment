
let myForm = document.getElementById('myForm');
let textInput = document.getElementById('phrase');
let errorDiv = document.getElementById('error');
let myUl = document.getElementById('attempts');

if(myForm){
    myForm.addEventListener('submit',(event)=>{
        event.preventDefault();
        if(textInput.value){
            errorDiv.hidden = true;
           checkPalindrome(textInput.value).then((isPalindrome) => {
            const className = isPalindrome ? 'is-palindrome' : 'not-palindrome';
            $('#attempts').append($('<li>', {class: className, text: textInput.value}));
            myForm.reset();
           }).catch((err)=>{
            errorDiv.hidden = false;
            errorDiv.innerHTML = err;
            myForm.reset();

           })
        textInput.focus();
        }
        else {
			errorDiv.hidden = false;
            errorDiv.innerHTML = 'You Must Enter a value!';
            textInput.focus();
            myForm.reset();
		}
    })
}


const checkPalindrome = async (str) => {
    if(!str) throw "You need to enter some text";
    
    if(typeof str == "string" && /[a-z-0-9]/.test(str.toLowerCase())){
    str = _cleanInput(str.toLowerCase());
    
    return str === str.split('').reverse().join('');
    }
    else{
        return false;
    }
};

const _cleanInput = (str) => {
    return str.replace(/\W/g, '').toLowerCase();
};
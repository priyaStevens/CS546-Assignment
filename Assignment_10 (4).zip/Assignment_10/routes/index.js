
 const auth = require("../data/auth");
const path = require('path');
const express = require('express');
const session = require('express-session');

module.exports = app => {
  app.get("/", async(req, res) => {
    try{
    if(req.session.user){     
     res.redirect('/private');
    }
    else{
    res.render("layouts/login");
    }
  }
  catch(e){
    res.sendStatus(500);
  }
  });

app.post("/login", async(req, res,next) => {
    const userName = req.body.username;
    const password = req.body.password;
    const passworddInDB = auth.getPassword(userName);
    try{
    if (passworddInDB && auth.matchPassword(password, passworddInDB)) {
      req.session.user = req.body.username;
      res.redirect("/private");
    }
    else
    res.status(401).render("layouts/login",{'error':"user id and password does not match, please try again."});
    return;
  }
    catch(e){
      res.sendStatus(500);
    } 
  });

  app.get("/private", async(req, res,next) => {
    try{
     if(req.session.user && req.session.user != undefined){
      const user_data = await auth.getUserfromSession(req.session.user);
      res.render('layouts/private',{'user_data': user_data});
  }
    else{
      return res.status(403).json({ error: '403: user is not logged in' });
    }
  }
  catch(e){
    res.sendStatus(500);
  }
  });

  app.get("/logout", async(req, res) => {
    try{
    req.session.destroy();
    res.clearCookie('AuthCookie');
    res.render("layouts/logout",{'message':"user logged out"});
    }
    catch(e){
      res.sendStatus(500);
    }
  });

  app.use('*', (req, res) => {
		res.sendStatus(404);
	});
};

module.exports = {
	users: require("./auth")
}
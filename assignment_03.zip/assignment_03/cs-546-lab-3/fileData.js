const bluebird = require("bluebird");
const Promise = bluebird.Promise;

const prompt = bluebird.promisifyAll(require("prompt"));
const fs = bluebird.promisifyAll(require("fs"));


async function readTxtAsString(fileNameVal){
        const file = await fs.readFileSync(fileNameVal,'utf8',(err,data)=>{
        if(err){
            throw err;
        }
        return data;
    });
  return file;

}
async function getFileAsString(path){
    if(path == undefined){
        throw "input is not valid";
    }
    const textData = await readTxtAsString(path);
    return textData;
  }
    
  async function readTxtAsJson(fileNameVal){
  const jsonFile = await fs.readFileSync(fileNameVal, 'utf8',(err, data) => 
    {   if (err) throw err;
        console.log(JSON.parse(data));
      });
      return jsonFile;
}
    async function getFileAsJSON(path){
        if(path == undefined){
            throw "input is not valid."
        }
        const jsonData = await readTxtAsJson(path);
        return jsonData;
    }

    async function savetxtString(file,text){
        const data = new Uint8Array(Buffer.from(text) );
         fs.writeFile(
             file, (err,data)=>{
                if(err){
                    throw err;
                }
                return true;
            });            
    }
    async function saveStringToFile(path, text){
        if(path == undefined || text == undefined){
            throw "input data is not valid."
        }
        const writeResult = await savetxtString(path,text);
    }

    async function saveTextJson(file,obj){
        const strdata =  JSON.stringify(obj);
        const data = new Uint8Array(Buffer.from(strdata) );
      await fs.writeFile(file, data, (err) => {
        if (err) {
            throw err;}
       return "true";
});
    }
    
    async function saveJSONToFile(path, obj){
        if(path == undefined || obj == undefined){
            throw "input data is not valid."
        }
        let text = await saveTextJson(path,obj);
    }

 

module.exports = {
    getFileAsString,
    getFileAsJSON,
    saveStringToFile,
    saveJSONToFile
};
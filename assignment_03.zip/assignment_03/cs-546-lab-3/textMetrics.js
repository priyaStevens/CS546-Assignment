const bluebird = require("bluebird");
const Promise = bluebird.Promise;

const prompt = bluebird.promisifyAll(require("prompt"));
const fs = bluebird.promisifyAll(require("fs"));

const Isalphaletter = function(ch){
    if(typeof ch === "string" && ch.length === 1 && /[a-z]/.test(ch)){
        return true;
    }
    else false;
}

const isvalidText = function(data){
    if(typeof data === "string" && data != undefined){
        if(/[a-z]/.test(data.toLowerCase()))
        return data;
    }
    throw "not a valid text."
}
const isValidWord = function(value){
    if(typeof value==="string" && value != undefined){
        if(/[a-z]/.test(value.toLowerCase())){
        return true;}
    }
    else{
        return false;
    }
}
async function createMetrics(text){

   let isLetter = [] ;
   let isNonLetter=[];
   let isVowel = [];
   let isWord=[];
   let totalwords;
   let word='';
   let uniqueWords = [];
   let longWords =[];
   let averageLengthWords;
   let wordOccurance = {};
   let isConsonants =[];
   let l = 0;
   let v = 0;
   let c = 0;
   let w = 0;
   let nl = 0;
   let objText ={}

   if(isvalidText(text))
    for(let i=0; i<text.length; i++){
        if(Isalphaletter(text.charAt(i).toLowerCase())){
            isLetter[l] =  text.charAt(i);
             l = l+1;

            let vowels = ['a','e','i','o','u'];

            if (vowels.indexOf(text.charAt(i))!=-1){
                isVowel[v] = text.charAt(i);
                v = v+1;
                word = word + text.charAt(i);
            }

            else{
                isConsonants[c] = text.charAt(i);
                c = c+1;
                word = word + text.charAt(i) ;
            }
            
        }
        else {

            isNonLetter[nl] = text.charAt(i);
            nl = nl+1;

            if(isValidWord(word))
             {
                isWord[w] = word.toLocaleLowerCase();
                w=w+1;
                word = '';
                }        
    }       
}

let unique = 0,lw = 0 , totalWordLength =0;
   for(let index=0; index<isWord.length; index++)
   {
       if(isWord[index] == isWord[index].toLocaleLowerCase()){
           if(uniqueWords.indexOf(isWord[index]) == -1){
           uniqueWords[unique] = isWord[index];
           unique += 1; 
       }
    }
    
    let val = isWord[index];
       if(val in wordOccurance){
           wordOccurance[val] = wordOccurance[val]+1;
       }
       else{
        wordOccurance[val] = 1;
       }

       if(isWord[index].length>=6){
        longWords[lw]=isWord[index]
        lw = lw+1;
       }

   totalWordLength = totalWordLength + isWord[index].length;
   
  }
  averageLengthWords = totalWordLength / isWord.length;

  objText["totalLetters"] = isLetter.length;
   objText["totalNonLetters"] = isNonLetter.length;
   objText["totalWords"] = isWord.length;
   objText["totalVowels"] = isVowel.length;
   objText["totalConsonants"] = isConsonants.length;
   objText["uniqueWords"] = uniqueWords.length;
   objText["longWords"] = longWords.length;
   objText["averageWordLength"] = averageLengthWords;
   objText["wordOccurrences"] = wordOccurance;
 return objText;
}


module.exports={
    createMetrics
};
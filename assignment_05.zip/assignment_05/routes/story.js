const express = require("express");
const router = express.Router();

const abouttData=
  {
    "storyTitle": "My Story",
    "story": "I am a computer science graduate student at Stevens, started college in Spring 2020.\nI want to become a Data Scientist, at the same time I want to get a good exposuer of front end technologies.\nThis Semester I am taking courses like Web Programming, RDBMS and KDD."
  }


router.get("/", async (req, res) => {
    try {
      const educationList = await abouttData;
      res.json(educationList);
    } catch (e) {
      res.status(500).send();
    }
  });

  module.exports = router;
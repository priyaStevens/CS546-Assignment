const express = require("express");
const router = express.Router();

const educationObject = [
  {
    "schoolName": "Don Bosco",
    "degree": "High school",
    "favoriteClass": "Maths",
    "favoriteMemory": "Play time with friends"
  },
  {
    "schoolName": "LPS",
    "degree": "Secondary High School",
    "favoriteClass": "Chemistry",
    "favoriteMemory": "school camp"
  },
  {
    "schoolName": "Up Tech",
    "degree": "B.Tech.",
    "favoriteClass": "RDBMS",
    "favoriteMemory": "college fest"
  },
]
router.get("/", async (req, res) => {
    try {
      const educationList = await educationObject;
      res.json(educationList);
    } catch (e) {
      res.status(500).send();
    }
  });

  module.exports = router;
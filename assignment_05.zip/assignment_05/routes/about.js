const express = require("express");
const router = express.Router();


const aboutData=
  {"name": "Priya Gupta",
  "cwid": "10457442",
  "biography": "My name is Priya.I am studying Comuter Science in my masters.\n I am taking Web Programming CS-546 in first semester where I am learning concepts of web programming with Javascript and mongoDB." ,
  "favoriteShows": ["friends", "this is us", "narcos", "family man"],
  "hobbies": ["dancing", "cooking", "reading"]
}

router.get("/", async (req, res) => {
    try {
      const aboutList = await aboutData;
      res.json(aboutList);
    } catch (e) {
      res.status(500).send();
    }
  });

  module.exports = router;
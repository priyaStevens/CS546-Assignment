function checkIsObject(value){
    if(typeof value === "object"){
        return value;
    }
    else{
        throw `${value} is not object.`
    }
}

function deepEquality(obj1, obj2){
    if((obj1 != null || obj1 !=undefined) && (obj2 != null || obj2 !=undefined)
)
    {
        let Istrue = false ;
        checkIsObject(obj1);
        checkIsObject(obj2);
        if(obj1 === obj2){
            Istrue = true;
        }
        else{
             if(Object.keys(obj1).length == Object.keys(obj2).length){
                for(let k of Object.keys(obj1)){
                    if(obj2.hasOwnProperty(k) != true){
                        Istrue = false;
                        break;
                    }
                       else{
                           if(obj1[k] == obj2[k]){
                               Istrue = true;
                           }
                           else{
                               Istrue = false;
                               break;
                           }
                       }

                    }
                }
                else{
                    Istrue = false;
                }
             }
             return Istrue;
        }  
else{
    throw "input is not valid";
}
}


function uniqueElements(arr){
    if(arr !="" && arr != undefined){
        if(Array.isArray(arr)){
        let newArr = []; 
        let count = 0
            for(let i in  arr){
                if(newArr.indexOf(arr[i])<0){
                    newArr[count]=arr[i];
                    count++;
                }                        
            }      
            return newArr.length;
        }
        else{
            throw "input is not array";
        }
    }
    else{
        throw "input is empty";
    }
}

function chcekString(words){
  
    if(typeof(words) === "string"){
        return words;
    }
    else{
        throw `${words} input is not a string`;
    }
    }
function countOfEachCharacterInString(str){
    if(str != "" && str != undefined)
        {
            chcekString(str);

                let newArr= {} ;

                for(let i in str){
                    let charac = str[i];
                    if(charac in newArr)        
                        {
                            newArr[charac] =  newArr[charac]+1;
                        }
                    else
                        {
                            newArr[charac] = 1;
                        }       
            }
            return newArr;
    }
    else{
        throw "input data is null";
    }
}

module.exports = {
    uniqueElements,
    countOfEachCharacterInString,
    deepEquality
};
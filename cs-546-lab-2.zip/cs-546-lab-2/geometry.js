
function checkIsProperNumber(val,variablename){
    if((typeof(val) != 'number')){
        
        throw `${variablename} ${val} is not a valid number`;
    }
    if((Math.abs(val) != val)){
        throw "error";
    }
    if(isNaN(val)){
        throw `${variablename} ${val} is NaN`;
    }
}

module.exports = {

volumeOfRectangularPrism:(length, width, height)=>{
    checkIsProperNumber(length,"legth");
    checkIsProperNumber(width,"width");
    checkIsProperNumber(height,"height");

    return length*width*height;
},

surfaceAreaOfRectangularPrism:(length, width, height)=>{
    checkIsProperNumber(length,"legth");
    checkIsProperNumber(width,"width");
    checkIsProperNumber(height,"height");

    return (2)*(length*width + width*height + height*length);
},

volumeOfSphere:(radius)=>{
    checkIsProperNumber(radius,"radius");

    return (4/3) * Math.PI * radius * radius * radius;
},

surfaceAreaOfSphere:(radius)=>{
    checkIsProperNumber(radius,"radius");

    return 4 * Math.PI * radius * radius;
}

}
const resultRoutes = require("./isPalindrome");
const palindromData = require('./isPalindrome');
const path = require('path');

const constructorMethod = app => {

  app.use('/result', resultRoutes);

  app.get('/', (req, res) => {
		res.sendFile(path.resolve('index.html'));
	});
  
  app.use("*", (req, res) => {
    res.status(400).render('palindromechecker/error', { 'err': "Not Found" })
  });
};

module.exports = constructorMethod;
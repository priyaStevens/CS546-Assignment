const express = require('express');
const router = express.Router();
const palindrome = require('../checkIsPalindrome');


router.post("/", async(req,res)=>{
    try{
      const result = await palindrome.isPalindrome(req.body);
      res.render('palindromechecker/result',{ 'text-to-test': req.body['text-to-test'], 'result': result })
    }
    catch(e){
      res.status(400).render('palindromechecker/error', { 'err': e });
    }
    })

    module.exports = router;

  
  